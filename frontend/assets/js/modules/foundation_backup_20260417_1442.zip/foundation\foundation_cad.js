export const FLOORS = ['PH', 'R', '3', '2', '1'];

// 階別データストア
export const floorData = {};
FLOORS.forEach(f => {
  floorData[f] = {
    nodes: [],   // {id, x, y}
    columns: [], // {id, nodeIndex, force_long, ratio_b}
    beams: [],   // {id, n1, n2}
    slabs: [],   // {id, nodeIds:[], edgeConditions:[]}
    diaphragms: [], // {id, nodeIds:[]}
    walls: [], // {id, n1, n2, multiplier, axisName:""}
    anchorBolts: {}, // { axisName: { species: 'J1', m12: 0, m16: 0 } }
    floorHeight: 2730, // 基準階高 (mm)
  };
});
export let currentFloor = '1';

// Undo/Redo履歴
export let history = [];
export let historyIndex = -1;

// 採番用
export let nextId = { node: 1, beam: 1, slab: 1, diaphragm: 1, wall: 1 };

export function setFloor(f) {
  currentFloor = f;

  // --- [Task 1 修正点] デバッグ・ダッシュボード ---
  console.log(`%c--- Floor Data Dashboard (${f}F selected) ---`, "color: #3498db; font-weight: bold;");
  FLOORS.forEach(floor => {
    const d = floorData[floor];
    if (d) {
      const counts = [
        `柱:${d.columns.length}`,
        `梁:${d.beams.length}`,
        `壁:${d.walls.length}`,
        `盤:${d.slabs.length}`,
        `構:${d.diaphragms.length}`
      ].join(' / ');
      console.log(`[${floor}F] ${counts}`);
    }
  });
  // --- 修正点ここまで ---
}

// 履歴の記録
export function pushHistory() {
  const snapshot = JSON.parse(JSON.stringify(floorData));
  if (historyIndex < history.length - 1) {
    history = history.slice(0, historyIndex + 1);
  }
  history.push(snapshot);
  // 最大50件保持
  if (history.length > 50) history.shift();
  else historyIndex++;
}

export function undo() {
  if (historyIndex > 0) {
    historyIndex--;
    Object.assign(floorData, JSON.parse(JSON.stringify(history[historyIndex])));
    return true;
  }
  return false;
}

export function redo() {
  if (historyIndex < history.length - 1) {
    historyIndex++;
    Object.assign(floorData, JSON.parse(JSON.stringify(history[historyIndex])));
    return true;
  }
  return false;
}

// 初期履歴
pushHistory();

// DXF表示用（foundation_dxf.jsからセットされる）
export function updateNextId(val) {
  if (val && typeof val === 'object') {
    Object.assign(nextId, val);
  }
}

// DXF表示用（foundation_dxf.jsからセットされる）
export let dxfLines = [];
export let dxfTexts = [];
export let dxfLayerVisibility = {};
export let dxfVAxes = [];
export let dxfHAxes = [];

export function setDxfData(lines, texts, layers, vA = [], hA = []) {
  dxfLines = lines;
  dxfTexts = texts;
  dxfLayerVisibility = layers;
  dxfVAxes = vA;
  dxfHAxes = hA;
}

import { 
  canvas, ctx, W, H, scale, panX, panY, 
  initCanvas, resizeCanvas, worldToScreen, screenToWorld, setPanScale,
  drawDxf, drawSlabs, drawDiaphragms, drawBeams, drawWalls, 
  drawNodes, drawColumns, drawGrid, drawPreviews,
  distToSegment, pointInPolygon
} from './rendering_helpers.js';

export { canvas, ctx, W, H, scale, panX, panY, initCanvas, resizeCanvas, worldToScreen, screenToWorld, setPanScale };

export function panCanvas(dx, dy) {
  setPanScale(panX + dx, panY + dy, scale);
}

// Renderロジック
export function render(state) {
  const canvasEl = document.getElementById('cadCanvas');
  if (!canvasEl) return;
  const ctx = canvasEl.getContext('2d');
  if (!ctx) return;

  const { 
    currentTool, hoveredNode, selectedElement, selectedElements = [],
    beamStartNode, currentPolygon, mouseWorld,
    showGrid, showDxf, showLabels, viewMode
  } = state;

  // 複数選択ハイライト判定ヘルパー
  const isMultiSel = (type, idx) => {
    if (selectedElement && selectedElement.type === type && selectedElement.index === idx) return true;
    return selectedElements.some(el => el.type === type && el.index === idx);
  };

  ctx.clearRect(0, 0, canvasEl.width, canvasEl.height);
  const fd = floorData[currentFloor];

  const showCol   = document.getElementById('vis-col')   ? document.getElementById('vis-col').checked   : true;
  const showBeam  = document.getElementById('vis-beam')  ? document.getElementById('vis-beam').checked  : true;
  const showFbeam = document.getElementById('vis-fbeam') ? document.getElementById('vis-fbeam').checked : true;
  const showSlab  = document.getElementById('vis-slab')  ? document.getElementById('vis-slab').checked  : true;
  const showDiaph = document.getElementById('vis-diaph') ? document.getElementById('vis-diaph').checked : true;
  const showWall  = document.getElementById('vis-wall')  ? document.getElementById('vis-wall').checked  : true;

  const isSlabDivideMode = (currentTool === 'slabDivide');

  // 分割された描画関数を順次実行
  drawDxf(ctx, isSlabDivideMode);
  drawSlabs(ctx, fd, isMultiSel, showSlab);
  drawDiaphragms(ctx, fd, isMultiSel, showDiaph, isSlabDivideMode);
  drawBeams(ctx, fd, isMultiSel, showBeam, showFbeam, viewMode);
  drawPreviews(ctx, state, fd); // ゴムバンド
  drawWalls(ctx, fd, selectedElement, showWall, isSlabDivideMode);
  drawNodes(ctx, fd, hoveredNode, isSlabDivideMode);
  drawColumns(ctx, fd, hoveredNode, selectedElement, showCol, isSlabDivideMode);
  drawGrid(ctx, selectedElement, showGrid);

  // ─── 分割モード用オーバーレイ描画 ───
  if (isSlabDivideMode) {
    drawSlabDivideOverlay();
  }
}

// スラブ亀甲分割モード用のオーバーレイ描画（今後、ガイド線などを記述）
export function drawSlabDivideOverlay() {
}

export function findAxisNear(wx, wy) {
  const TOL_WORLD = 15 / scale;
  for (let i=0; i<dxfVAxes.length; i++) {
     if (Math.abs(wx - dxfVAxes[i].x) < TOL_WORLD) return {dir: 'v', index: i};
  }
  for (let i=0; i<dxfHAxes.length; i++) {
     if (Math.abs(wy - dxfHAxes[i].y) < TOL_WORLD) return {dir: 'h', index: i};
  }
  return null;
}

export function removeAxis(dir, idx) {
  let removedPos;
  if (dir === 'v') {
     removedPos = dxfVAxes[idx].x;
     dxfVAxes.splice(idx, 1);
  } else {
     removedPos = dxfHAxes[idx].y;
     dxfHAxes.splice(idx, 1);
  }
  
  FLOORS.forEach(f => {
     let nds = floorData[f].nodes;
     for (let i = nds.length - 1; i >= 0; i--) {
        const n = nds[i];
        if ((dir === 'v' && Math.abs(n.x - removedPos) < 5) || (dir === 'h' && Math.abs(n.y - removedPos) < 5)) {
           nds.splice(i, 1);
           for (let j = floorData[f].columns.length - 1; j >= 0; j--) {
               let c = floorData[f].columns[j];
               if (c.nodeIndex === i) floorData[f].columns.splice(j, 1);
               else if (c.nodeIndex > i) c.nodeIndex--;
           }
           for (let j = floorData[f].beams.length - 1; j >= 0; j--) {
               let b = floorData[f].beams[j];
               if (b.n1 === i || b.n2 === i) floorData[f].beams.splice(j, 1);
               else {
                   if (b.n1 > i) b.n1--;
                   if (b.n2 > i) b.n2--;
               }
           }
           for (let j = floorData[f].slabs.length - 1; j >= 0; j--) {
               let s = floorData[f].slabs[j];
               if (s.nodeIds.includes(i)) floorData[f].slabs.splice(j, 1);
               else {
                   for(let k=0; k<s.nodeIds.length; k++) {
                       if (s.nodeIds[k] > i) s.nodeIds[k]--;
                   }
               }
           }
           if (floorData[f].diaphragms) {
               for (let j = floorData[f].diaphragms.length - 1; j >= 0; j--) {
                   let d = floorData[f].diaphragms[j];
                   if (d.nodeIds.includes(i)) floorData[f].diaphragms.splice(j, 1);
                   else {
                       for(let k=0; k<d.nodeIds.length; k++) {
                           if (d.nodeIds[k] > i) d.nodeIds[k]--;
                       }
                   }
               }
           }
           if (floorData[f].walls) {
               for (let j = floorData[f].walls.length - 1; j >= 0; j--) {
                   let w = floorData[f].walls[j];
                   if (w.n1 === i || w.n2 === i) floorData[f].walls.splice(j, 1);
                   else {
                       if (w.n1 > i) w.n1--;
                       if (w.n2 > i) w.n2--;
                   }
               }
           }
        }
     }
  });
}

export function addAxis(dir, idx, dist) {
  if (dir === 'v') {
     const axObj = dxfVAxes[idx];
     const newX = axObj.x + dist;
     const newL = axObj.label ? axObj.label + "'" : '';
     dxfVAxes.push({x: newX, lines: [], label: newL});
     FLOORS.forEach(f => {
       dxfHAxes.forEach(ha => {
          floorData[f].nodes.push({ id: 'NEW', x: newX, y: ha.y });
       });
     });
  } else {
     const axObj = dxfHAxes[idx];
     const newY = axObj.y + dist;
     const newL = axObj.label ? axObj.label + "'" : '';
     dxfHAxes.push({y: newY, lines: [], label: newL});
     FLOORS.forEach(f => {
       dxfVAxes.forEach(va => {
          floorData[f].nodes.push({ id: 'NEW', x: va.x, y: newY });
       });
     });
  }
}

export function rebuildNodeIds() {
  FLOORS.forEach(f => {
    const nds = floorData[f].nodes;
    nds.forEach(n => {
      const va = dxfVAxes.find(a => Math.abs(a.x - n.x) < 5);
      const ha = dxfHAxes.find(a => Math.abs(a.y - n.y) < 5);
      if (va && ha) {
        const baseId = (va.label && ha.label) ? (va.label + ha.label) : '';
        if (!baseId) return; // keep current if unknown
        // 枝番（_1等）の完全禁止
        n.id = baseId;
      }
    });
  });
}

export function findSnapNode(wx, wy, tolWorld = null) {
  const SNAP_RADIUS_WORLD = tolWorld !== null ? tolWorld : (10 / scale);
  const fd = floorData[currentFloor];
  let best = null, bestD = SNAP_RADIUS_WORLD;
  fd.nodes.forEach((n, i) => {
    const d = Math.hypot(n.x - wx, n.y - wy);
    if (d < bestD) { bestD = d; best = i; }
  });
  return best;
}

export function findBeamNear(wx, wy) {
  const fd = floorData[currentFloor];
  const TOL_WORLD = 8 / scale;
  const showBeam = document.getElementById('vis-beam') ? document.getElementById('vis-beam').checked : true;
  const showFbeam = document.getElementById('vis-fbeam') ? document.getElementById('vis-fbeam').checked : true;

  for (let i = 0; i < fd.beams.length; i++) {
    const b = fd.beams[i];
    const isFbeam = (b.type === 'foundation_beam' || b.tributaryWidth !== undefined || b.groundPressure !== undefined);
    if (isFbeam && !showFbeam) continue;
    if (!isFbeam && !showBeam) continue;

    const n1 = fd.nodes[b.n1];
    const n2 = fd.nodes[b.n2];
    if (!n1 || !n2) continue;
    const d = distToSegment(wx, wy, n1.x, n1.y, n2.x, n2.y);
    if (d < TOL_WORLD) return i;
  }
  return null;
}

export function findWallNear(wx, wy) {
  const fd = floorData[currentFloor];
  const TOL_WORLD = 10 / scale; // 8px から 10px に緩和
  const showWall = document.getElementById('vis-wall') ? document.getElementById('vis-wall').checked : true;
  if (!showWall || !fd.walls) return null;

  for (let i = 0; i < fd.walls.length; i++) {
    const w = fd.walls[i];
    const n1 = fd.nodes[w.n1];
    const n2 = fd.nodes[w.n2];
    if (!n1 || !n2) continue;
    const d = distToSegment(wx, wy, n1.x, n1.y, n2.x, n2.y);
    if (d < TOL_WORLD) return i;
  }
  return null;
}

export function findSlabAt(wx, wy) {
  const showSlab = document.getElementById('vis-slab') ? document.getElementById('vis-slab').checked : true;
  if (!showSlab) return null;

  const fd = floorData[currentFloor];
  for (let i = fd.slabs.length - 1; i >= 0; i--) {
    const sl = fd.slabs[i];
    const pts = sl.nodeIds.map(ni => fd.nodes[ni]).filter(Boolean);
    if (pts.length < 3) continue;
    if (pointInPolygon(wx, wy, pts)) return i;
  }
  return null;
}

export function findDiaphragmAt(wx, wy) {
  const showDiaph = document.getElementById('vis-diaph') ? document.getElementById('vis-diaph').checked : true;
  if (!showDiaph) return null;

  const fd = floorData[currentFloor];
  if (!fd.diaphragms) return null;
  for (let i = fd.diaphragms.length - 1; i >= 0; i--) {
    const dia = fd.diaphragms[i];
    const pts = dia.nodeIds.map(ni => fd.nodes[ni]).filter(Boolean);
    if (pts.length < 3) continue;
    if (pointInPolygon(wx, wy, pts)) return i;
  }
}

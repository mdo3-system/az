import { 
  floorData, FLOORS, currentFloor, setFloor, render, 
  findSnapNode, findBeamNear, findSlabAt, findDiaphragmAt, pushHistory, undo, redo,
  dxfLines, dxfTexts, dxfLayerVisibility, dxfVAxes, dxfHAxes, nextId, updateNextId, setDxfData 
} from './foundation_cad.js';
import { parseDxfFile } from './foundation_dxf.js';
import { callRender, fitAll } from './rendering_helpers.js';
import { 
  handleDelete, handleDeleteSelected, handleSelect, handleColumnPlace, handleBeamDraw, handleWallDraw, handleSlabDraw, finishPolygon, handleMouseHover 
} from './tool_handlers.js';
import { drawBeamStressOnCanvas, updateAllBeamsShortTermStress } from './stress_display.js';

// --- 定数とヘルパー ---
const API_BASE_URL = window.location.port === '5500' ? 'http://127.0.0.1:8000' : window.location.origin;
const STRESS_TOLERANCE = 50;
const isSamePoint = (p1, p2) => Math.hypot(p1.x - p2.x, p1.y - p2.y) < STRESS_TOLERANCE;

/**
 * foundation_main.js から移設された UI 設定とイベント登録の全ロジック
 */
export const setupEventHandlers = function(canvas, state) {
  // 💡 BUGFIX: window.state の安全な初期化
  window.state = state || window.state || { currentTool: 'selectGrid', selectedElements: [], currentPolygon: [] };
  
  // 💡 BUGFIX: 既存のゲッターがあれば削除し、読み書き自由なプロパティとして再定義（TypeError防止）
  try {
      delete window.currentFloor;
      delete window.floorData;
  } catch(e) {}
  
  window.floorData = floorData;
  window.currentFloor = currentFloor;

  // 💡 UI改善: 右パネルを非表示にして作業領域を最大化
  const rightPanel = document.getElementById('right-sidebar');
  if (rightPanel) rightPanel.style.display = 'none';

  // --- 内部ヘルパー: 壁クリーンアップ ---
  window.cleanupOrphanWalls = function(floorKey) {
    const fk = floorKey || currentFloor;
    const fdata = floorData[fk];
    if (!fdata || !fdata.walls) return 0;
    const colNodeIndices = new Set(fdata.columns.map(c => c.nodeIndex));
    const before = fdata.walls.length;
    fdata.walls = fdata.walls.filter(w => {
      const n1Valid = w.n1 !== undefined && w.n1 !== null && colNodeIndices.has(w.n1);
      const n2Valid = w.n2 !== undefined && w.n2 !== null && colNodeIndices.has(w.n2);
      return n1Valid && n2Valid;
    });
    const removed = before - fdata.walls.length;
    if (removed > 0) console.log(`[cleanupOrphanWalls] ${fk}階: ${removed}件の孤立した壁を除去しました。`);
    return removed;
  };

  // --- Toolbar Events ---
  document.getElementById('btnUndo')?.addEventListener('click', () => { if(undo()) { window.updateDataList?.(); window.updatePropertyPanel?.(); callRender(); } });
  document.getElementById('btnRedo')?.addEventListener('click', () => { if(redo()) { window.updateDataList?.(); window.updatePropertyPanel?.(); callRender(); } });

  // --- Floor Tabs ---
  document.querySelectorAll('#floorTabs button').forEach(btn => {
    btn.addEventListener('click', () => {
      document.querySelector('#floorTabs button.active')?.classList.remove('active');
      btn.classList.add('active');
      setFloor(btn.dataset.floor);
      // 💡 内部変数とグローバル変数の両方を最新状態に更新
      window.currentFloor = btn.dataset.floor; 
      const floorInput = document.getElementById('floorHeight');
      if (floorInput) floorInput.value = floorData[currentFloor].floorHeight || 2730;
      state.selectedElement = null;
      state.beamStartNode = null;
      state.currentPolygon = [];
      updateLayerCheckboxes();
      window.updatePropertyPanel?.();
      window.updateDataList?.();
      callRender();
    });
  });

  // --- Tool Tabs ---
  const setTool = (t) => {
    state.currentTool = t;
    document.querySelectorAll('#toolGroup .tool-btn').forEach(b => b.classList.remove('active'));
    document.querySelector(`#toolGroup .tool-btn[data-tool="${t}"]`)?.classList.add('active');
    canvas.style.cursor = (t === 'selectGrid' || t === 'selectElem') ? 'default' : t === 'delete' ? 'not-allowed' : 'crosshair';
    state.beamStartNode = null;
    state.currentPolygon = [];
    state.selectedElement = null;
    state.selectedElements = [];
    window.updatePropertyPanel?.();
    callRender();
  };
  document.querySelectorAll('#toolGroup .tool-btn').forEach(btn => {
    btn.addEventListener('click', () => setTool(btn.dataset.tool));
  });

  // --- DXF Upload ---
  document.getElementById('dxfFileInput')?.addEventListener('change', e => {
    const file = e.target.files[0];
    if (!file) return;
    const fd = floorData[currentFloor];
    const hasData = fd.nodes.length > 0 || fd.columns.length > 0 || fd.walls.length > 0 || fd.beams.length > 0 || fd.slabs.length > 0;
    let keepExisting = true;
    if (hasData) keepExisting = window.confirm("既存データを残して追加しますか？\n[OK]追加 [キャンセル]上書き");
    if (!keepExisting) { fd.nodes = []; fd.columns = []; fd.walls = []; fd.beams = []; fd.slabs = []; fd.diaphragms = []; }
    parseDxfFile(file, keepExisting, (err, dxf) => {
      if (!err) {
        document.getElementById('dxfFileName').textContent = '✓ ' + file.name;
        document.getElementById('dxfUploadArea')?.classList.add('loaded');
        updateLayerCheckboxes();
        window.updatePropertyPanel?.();
        window.updateDataList?.();
        fitAll();
        window.cleanupOrphanWalls(currentFloor);
        window.updateDataList?.();
      }
      e.target.value = '';
    });
  });

  // --- JSON Save / Load ---
  document.getElementById('btn-save-json')?.addEventListener('click', (e) => {
    e.preventDefault();
    e.stopPropagation(); // 💡 バブリングによる意図しない挙動を阻止
    const data = { floorData, nextId, dxfLines, dxfTexts, dxfLayerVisibility, dxfVAxes, dxfHAxes };
    const blob = new Blob([JSON.stringify(data)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url; a.download = 'foundation_data.json'; a.click();
    console.log("%c[SAVE] データの保存を実行しました。※もし画面が初期化される場合は、Live Server等の自動更新機能を停止するか、保存先をプロジェクト外（デスクトップ等）にしてください。", "color: #f1c40f; font-weight: bold;");
    setTimeout(() => URL.revokeObjectURL(url), 100);
  });

  document.getElementById('json-upload')?.addEventListener('change', e => {
    const file = e.target.files[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = ev => {
      try {
        const data = JSON.parse(ev.target.result);
        if (data.floorData) Object.keys(data.floorData).forEach(f => { if (floorData[f]) floorData[f] = data.floorData[f]; });
        if (data.nextId) updateNextId(data.nextId);
        setDxfData(data.dxfLines || [], data.dxfTexts || [], data.dxfLayerVisibility || {}, data.dxfVAxes || [], data.dxfHAxes || []);
        
        setFloor('1');
        state.selectedElement = null;
        state.selectedElements = [];
        
        updateLayerCheckboxes();
        window.updatePropertyPanel?.();
        window.updateDataList?.();
        
        fitAll();
        window.syncSlabDataToBeams?.();
        callRender();
        
        console.log(`[JSON Load] data restored. nextId: ${data.nextId}`);
        alert('全階層のデータを復旧・統合しました。');
      } catch (err) { 
        console.error('JSON読込失敗:', err);
        alert('JSON読込失敗'); 
      }
      e.target.value = '';
    };
    reader.readAsText(file);
  });

  // --- Display Toggles ---
  document.getElementById('showGrid')?.addEventListener('change', e => { state.showGrid = e.target.checked; callRender(); });

  // --- Canvas Events ---
  canvas.addEventListener('wheel', e => {
    e.preventDefault();
    const rect = canvas.getBoundingClientRect();
    const sx = e.clientX - rect.left, sy = e.clientY - rect.top;
    import('./foundation_cad.js').then(cad => {
      const w0 = cad.screenToWorld(sx, sy);
      const newS = Math.max(0.001, Math.min(50, cad.scale * (e.deltaY < 0 ? 1.12 : 1/1.12)));
      cad.setPanScale(sx - w0.x * newS, sy + w0.y * newS, newS);
      callRender();
    });
  }, {passive:false});

  canvas.addEventListener('contextmenu', e => e.preventDefault());

  canvas.addEventListener('mousedown', async e => {
    if (e.button === 2) {
      state.isPanning = true;
      state.panStartMouse = {x: e.offsetX, y: e.offsetY};
      import('./foundation_cad.js').then(cad => { state.panStartOffset = {x: cad.panX, y: cad.panY}; });
      canvas.style.cursor = 'grabbing';
      return;
    }
    if (e.button !== 0) return;
    const cad = await import('./foundation_cad.js');
    const fd = floorData[currentFloor];
    const wc = cad.screenToWorld(e.offsetX, e.offsetY);
    if (state.currentTool === 'delete') { if (await handleDelete(state, fd, wc, cad)) return; return; }
    const snapIdx = state.currentTool === 'column' ? cad.findSnapNode(wc.x, wc.y, 300) : cad.findSnapNode(wc.x, wc.y);
    switch (state.currentTool) {
      case 'selectGrid': case 'selectElem': handleSelect(state, fd, wc, snapIdx, cad, e.shiftKey || e.ctrlKey); break;
      case 'column': handleColumnPlace(state, fd, snapIdx); break;
      case 'beam': handleBeamDraw(state, fd, snapIdx, 'beam'); break;
      case 'fbeam': handleBeamDraw(state, fd, snapIdx, 'fbeam'); break;
      case 'wall': handleWallDraw(state, fd, snapIdx); break;
      case 'slab': case 'diaphragm': handleSlabDraw(state, snapIdx); break;
    }
  });

  canvas.addEventListener('mousemove', async e => {
    const rect = canvas.getBoundingClientRect();
    const sx = e.clientX - rect.left, sy = e.clientY - rect.top;
    const cad = await import('./foundation_cad.js');
    if (state.isPanning) {
      const dx = sx - state.panStartMouse.x, dy = sy - state.panStartMouse.y;
      cad.setPanScale(state.panStartOffset.x + dx, state.panStartOffset.y + dy, cad.scale);
      callRender();
    } else {
      const fd = floorData[currentFloor];
      handleMouseHover(state, fd, cad.screenToWorld(sx, sy), cad);
    }
  });

  canvas.addEventListener('mouseup', e => {
    if (e.button === 2) {
      state.isPanning = false;
      canvas.style.cursor = ['selectGrid','selectElem'].includes(state.currentTool) ? 'default' : state.currentTool === 'delete' ? 'not-allowed' : 'crosshair';
    }
  });

  // --- Keyboard Events ---
  window.addEventListener('keydown', e => {
    if (['INPUT','TEXTAREA','SELECT'].includes(document.activeElement.tagName)) return;
    if (e.key === 'z' && (e.ctrlKey || e.metaKey)) {
      if (e.shiftKey) { if (redo()) { window.updatePropertyPanel?.(); window.updateDataList?.(); callRender(); } }
      else { if (undo()) { state.selectedElement = null; window.updatePropertyPanel?.(); window.updateDataList?.(); callRender(); } }
      e.preventDefault();
    }
    const moveRaw = 20;
    import('./foundation_cad.js').then(cad => {
      const dWorld = moveRaw / cad.scale;
      let handled = false;
      if (e.key === 'ArrowUp') { cad.panCanvas(0, dWorld); handled = true; }
      if (e.key === 'ArrowDown') { cad.panCanvas(0, -dWorld); handled = true; }
      if (e.key === 'ArrowLeft') { cad.panCanvas(dWorld, 0); handled = true; }
      if (e.key === 'ArrowRight') { cad.panCanvas(-dWorld, 0); handled = true; }
      if (handled) { e.preventDefault(); callRender(); }
    });
  });

  document.addEventListener('keydown', e => {
    if (['INPUT','TEXTAREA','SELECT'].includes(e.target.tagName)) return;
    const tools = { V:'selectGrid', A:'selectElem', C:'column', B:'beam', F:'fbeam', S:'slab', H:'diaphragm', W:'wall' };
    const tool = tools[e.key.toUpperCase()];
    if (tool) setTool(tool);
    else if (e.key.toUpperCase() === 'ENTER' && ['slab','diaphragm'].includes(state.currentTool)) finishPolygon(state, floorData[currentFloor]);
    else if (e.key === 'Escape') { state.beamStartNode = null; state.currentPolygon = []; state.selectedElement = null; window.updatePropertyPanel?.(); callRender(); }
    else if (e.key === 'Delete') handleDeleteSelected(state, floorData[currentFloor]);
    else if (e.key.toUpperCase() === 'F') fitAll();
  });

  // 初期化完了時に一回描画
  setTimeout(() => {
    window.fitAll?.(); // キャンバスを新しいサイズにフィット
    try { 
        if (typeof window.updateDataList === 'function') window.updateDataList(); 
        if (typeof window.updatePropertyPanel === 'function') window.updatePropertyPanel();
    } catch(e) { console.error('初期リスト更新エラー:', e); }
    window.callRender?.();
    console.log('[UI] 初期描画完了：右パネル閉鎖・キャンバス最大化');
  }, 150);
};

// --- グローバルハンドラ群 (event_handlers.js モジュール内で定義) ---

window.updateDefaultWallMultiplier = function(val) {
  if (window.state) window.state.defaultWallMultiplier = Math.min(7.0, Math.max(0, parseFloat(val) || 1.0));
};

window.updateFloorHeight = function(val) {
  const fd = floorData[currentFloor];
  if (fd) {
    fd.floorHeight = parseInt(val) || 2730;
    window.updatePropertyPanel?.();
    window.updateDataList?.();
    callRender();
  }
};



window.handleMultiPropChange = function(field, value) {
  if (window.state && window.state.selectedElements) {
    window.state.selectedElements.forEach(({type, index}) => window.handlePropChange(type, index, field, value));
  }
  callRender();
};

window.selectListItem = function(type, index) {
  if (!window.state) window.state = {}; // 強制復旧
  
  // 💡 BUGFIX: 右パネル(property_panel_builders)が小文字を期待している可能性があるため、typeはそのままstateへ渡す
  window.state.selectedElement = { type: type, index: index };
  window.state.selectedElements = [{ type: type, index: index }];
  
  const visIdMap = { 
    column:'vis-col', beam:'vis-beam', perimeterbeam:'vis-fbeam', perimeterBeam:'vis-fbeam', 
    slab:'vis-slab', diaphragm:'vis-diaph', wall:'vis-wall' 
  };
  const visId = visIdMap[type];
  if (visId) {
    const el = document.getElementById(visId);
    if (el && !el.checked) { el.checked = true; el.dispatchEvent(new Event('change')); }
  }

  // 💡 モーダル呼び出し用には正規化（キャメルケース）を使用
  const popupType = type === 'perimeterbeam' ? 'perimeterBeam' : type;
  if (popupType === 'column') {
    if (typeof window.openColumnDetailModal === 'function') window.openColumnDetailModal(index);
  } else if (['beam','perimeterBeam'].includes(popupType)) {
    if (typeof window.openBeamStressPopup === 'function') window.openBeamStressPopup(popupType, index);
  } else if (popupType === 'slab') {
    if (typeof window.openSlabDetailModal === 'function') window.openSlabDetailModal(index);
  } else if (popupType === 'wall') {
    if (typeof window.openWallDetailModal === 'function') window.openWallDetailModal(index);
  } else if (popupType === 'diaphragm') {
    if (typeof window.openDiaphragmDetailModal === 'function') window.openDiaphragmDetailModal(index);
  }
  
  if (typeof window.updatePropertyPanel === 'function') window.updatePropertyPanel();
  if (typeof window.updateDataList === 'function') window.updateDataList();
  if (typeof window.callRender === 'function') window.callRender();
};

window.switchMenuTab = function(btn) {
  if (!window.state) window.state = { currentListTab: null };
  
  // アクティブ表示の切り替え
  document.querySelectorAll('[data-list]').forEach(b => b.classList.remove('active'));
  if (btn && btn.classList) {
      btn.classList.add('active');
      window.state.currentListTab = btn.dataset.list;
  }
  
  // 💡 リスト表示の更新を try-catch で保護し、確実に実行
  console.log(`[UI] タブ切り替え: ${window.state.currentListTab}`);
  try {
    if (typeof window.updateDataList === 'function') {
        window.updateDataList();
    } else {
        console.warn('updateDataList が未定義です。UIモジュールのロードを待機中...');
    }
  } catch(e) {
    console.error('updateDataList 実行エラー:', e);
  }
};

window.handleNwPdfUpload = async function(event) {
  const file = event.target.files[0];
  if (!file) return;
  const statusEl = document.getElementById('pdfStatus');
  if (statusEl) statusEl.textContent = "読込中...";
  const formData = new FormData(); formData.append('file', file);
  try {
    const resp = await fetch(`${API_BASE_URL}/api/v1/upload-nw-pdf`, { method:'POST', body:formData });
    if (!resp.ok) throw new Error('解析失敗');
    const data = await resp.json();
    const nw_dict = data.nw_dict || {};
    const fd = floorData[currentFloor];
    let count = 0;
    fd.columns.forEach(col => {
      const val = (nw_dict[currentFloor] && nw_dict[currentFloor][col.id]) ?? nw_dict[col.id];
      if (val !== undefined && val !== null) { col.nw = parseFloat(val); count++; }
    });
    if (statusEl) statusEl.textContent = `✓ ${count}件完了`;
    callRender(); window.updatePropertyPanel?.(); window.updateDataList?.();
  } catch (err) { if (statusEl) statusEl.textContent = "⚠ エラー"; }
  event.target.value = '';
};

window.syncSlabDataToBeams = function() {
    const fd = floorData[currentFloor];
    if (!fd) return;
    // 1. プロパティのリセット（エイリアス A, sigma_e, B も含む）
    fd.beams.forEach(b => { 
        b.tributaryWidth = b.B = 0; 
        b.tributaryArea = b.A = 0; 
        b.groundPressure = b.sigma_e = 0; 
        b.slabLoad = 0; b.slabLoadW = 0; b.totalLoad = 0; 
    });

    // 2. スラブ計算の実行（手動配置梁への伝達もここで行われる）
    if (fd.slabs && fd.slabs.length > 0 && window.calculateSlabTributary) {
      fd.slabs.forEach(slab => window.calculateSlabTributary(slab, fd.nodes, fd.beams));
    }

    // 3. 梁の合計荷重（線荷重）の算定
    fd.beams.forEach(b => {
      const n1 = fd.nodes[b.n1], n2 = fd.nodes[b.n2];
      if (!n1 || !n2) return;
      const L = Math.hypot(n2.x - n1.x, n2.y - n1.y) / 1000.0;
      b.slabLoadW = (L > 0.01 && (b.slabLoad || 0) > 0) ? (b.slabLoad / L) : ((b.tributaryWidth || 0) * (b.groundPressure || 0));
      b.totalLoad = b.slabLoadW + ((parseFloat(b.width)||0)/1000 * (parseFloat(b.depth)||0)/1000 * 24);
    });
    
    // 4. perimeterBeams 生成（スラブの縁から算出）
    const edgeMap = new Map();
    (fd.slabs || []).forEach((slab, sIdx) => {
      if (!slab.nodeIds) return;
      slab.nodeIds.forEach((v1, i) => {
        const v2 = slab.nodeIds[(i + 1) % slab.nodeIds.length];
        const key = [v1, v2].sort().join('-');
        if (!edgeMap.has(key)) edgeMap.set(key, []);
        // 💡 スラブから計算された面積(A)と接地圧(sigma)を edgeMap に保持
        edgeMap.get(key).push({ 
            slabIdx: sIdx, 
            edgeIdx: i, 
            A: slab.edgeAreas?.[i] || 0,
            B: slab.edgeLs?.[i] || 0, 
            sigma: slab.groundPressure || 20.0,
            Lo: slab.edgeLengths?.[i] || 0, 
            n1: v1, 
            n2: v2 
        });
      });
    });

    const oldPerimeterBeams = fd.perimeterBeams || [];
    fd.perimeterBeams = [];
    edgeMap.forEach(list => {
      const bId = `${fd.slabs[list[0].slabIdx].id}-B${list[0].edgeIdx+1}`;
      const oldB = oldPerimeterBeams.find(b => b.id === bId) || {};
      
      // 合計面積・最大接地圧・合計負担幅の算出
      const totalA = list.reduce((s, x) => s + x.A, 0);
      const totalB = list.reduce((s, x) => s + x.B, 0);
      const maxSigma = Math.max(...list.map(x => x.sigma));

      fd.perimeterBeams.push({ 
        id: bId, n1: list[0].n1, n2: list[0].n2, 
        length_m: Math.max(...list.map(x => x.Lo)), 
        tributaryArea: totalA, A: totalA,
        groundPressure: maxSigma, sigma_e: maxSigma,
        tributaryWidth: totalB, B: totalB,
        width: oldB.width || 150, 
        depth: oldB.depth || 640, 
        topRebar: oldB.topRebar || '1-D13', 
        bottomRebar: oldB.bottomRebar || '1-D13', 
        stirrupRebar: oldB.stirrupRebar || 'D10', 
        stirrupPitch: oldB.stirrupPitch || 200, 
        dt: oldB.dt || 70, 
        showReport: oldB.showReport !== undefined ? oldB.showReport : true,
        axisName: oldB.axisName || oldB.axis || '',
        axis: oldB.axis || oldB.axisName || '',
        anchorM12: oldB.anchorM12 || 0,
        anchorM16: oldB.anchorM16 || 0,
        // ✅ 根本バグ修正: スパン別プロパティ（配筋・寸法）を必ず引き継ぐ
        spans:     oldB.spans     ? JSON.parse(JSON.stringify(oldB.spans))     : [],
        spanProps: oldB.spanProps ? JSON.parse(JSON.stringify(oldB.spanProps)) : [],
      });
    });
    
    if (fd.perimeterBeams.length > 0) {
        console.log(`[Debug] Sample PerimeterBeam [0]: id=${fd.perimeterBeams[0].id}, A=${fd.perimeterBeams[0].A.toFixed(3)}, sigma=${fd.perimeterBeams[0].sigma_e.toFixed(3)}`);
    }

    // 💡 Mission 12: 重複した基礎梁（手動・自動生成）をクリーンアップ
    if (window.cleanupOverlappingBeams) {
        window.cleanupOverlappingBeams(fd);
    }

    if (currentFloor === '1' && window.updateAllBeamsShortTermStress) window.updateAllBeamsShortTermStress(fd);
    callRender();
};

/**
 * 補助関数: レイヤーチェックボックス更新
 */
export function updateLayerCheckboxes() {
  const container = document.getElementById('layerControlContainer');
  if (!container) return;
  container.innerHTML = '';
  const layerNames = Object.keys(dxfLayerVisibility).sort();
  const gridLayers = layerNames.filter(l => l.toUpperCase().includes('GRID') || l.toUpperCase().includes('GLID'));
  const otherLayers = layerNames.filter(l => !gridLayers.includes(l));
  const addRow = (l, isGrid = false) => {
    const row = document.createElement('div');
    row.className = 'prop-row';
    row.innerHTML = `<input type="checkbox" id="layer_${l}" ${dxfLayerVisibility[l]!==false?'checked':''}><label for="layer_${l}" style="font-size:10px;">${isGrid?'通り芯 (GLID/GRID)':l}</label>`;
    row.querySelector('input').addEventListener('change', e => {
      if(isGrid) gridLayers.forEach(gl => dxfLayerVisibility[gl] = e.target.checked);
      else dxfLayerVisibility[l] = e.target.checked;
      callRender();
    });
    container.appendChild(row);
  };
  if (gridLayers.length > 0) addRow('grid_group', true);
  otherLayers.forEach(l => addRow(l));
}

window.closeBeamStressPopup = () => document.getElementById('beamStressModal')?.remove();
window.updateBeamRebar = (type, index) => {
  const beam = type === 'beam' ? floorData[currentFloor].beams[index] : floorData[currentFloor].perimeterBeams[index];
  beam.width = parseFloat(document.getElementById('inp_w').value) || 150;
  beam.depth = parseFloat(document.getElementById('inp_d').value) || 640;
  beam.topRebar = document.getElementById('inp_topBar').value;
  beam.bottomRebar = document.getElementById('inp_botBar').value;
  window.handlePropChange(type, index, 'width', beam.width);
  window.handlePropChange(type, index, 'depth', beam.depth);
  window.handlePropChange(type, index, 'topRebar', beam.topRebar);
  window.handlePropChange(type, index, 'bottomRebar', beam.bottomRebar);
  window.openBeamStressPopup?.(type, index);
};
window.updateStirrup = (type, index) => {
  const beam = type === 'beam' ? floorData[currentFloor].beams[index] : floorData[currentFloor].perimeterBeams[index];
  beam.stirrupRebar = document.getElementById('inp_stp').value;
  beam.stirrupPitch = parseInt(document.getElementById('inp_pitch').value) || 200;
  window.handlePropChange(type, index, 'stirrupRebar', beam.stirrupRebar);
  window.handlePropChange(type, index, 'stirrupPitch', beam.stirrupPitch);
  window.openBeamStressPopup?.(type, index);
};
window.calcBeamResult = function(beam) {
  let Lo=beam.length_m||2, B=beam.tributaryWidth||0, sigma=beam.groundPressure||0;
  const fd = floorData[currentFloor];
  if(beam.type==='foundation_beam' && fd){ const n1=fd.nodes[beam.n1],n2=fd.nodes[beam.n2]; if(n1&&n2) Lo=Math.hypot(n2.x-n1.x,n2.y-n1.y)/1000; }
  const w = sigma*B, Mmid=beam.Mc||(w*Lo*Lo)/8, Mend=Math.max(beam.M1||0,beam.M2||0)||(w*Lo*Lo)/12, Q=(w*Lo)/2;
  const getAt=(s)=>{ if(!s)return 0; let total=0; s.replace(/\//g,'+').split('+').forEach(p=>{ const m=p.match(/(\d+)-D(\d+)/),m2=p.match(/D(\d+)/),map={10:71.3,13:126.7,16:198.6,19:286.5,22:387.1}; if(m)total+=parseInt(m[1])* (map[parseInt(m[2])]||0); else if(m2)total+= (map[parseInt(m2[1])]||0); }); return total; };
  const at_t=getAt(beam.topRebar), at_b=getAt(beam.bottomRebar);
  const bw=beam.width||150, ft=beam.ft||195, d=(beam.depth||640)-(beam.dt||70), j=7/8*d;
  const mt=at_t*ft*j*1e-6, mb=at_b*ft*j*1e-6, fs=0.7, fw=ft, s=beam.stirrupPitch||200;
  const aw= (beam.stirrupRebar||'D10').replace(/\//g,'+').split('+').reduce((sum,p)=>{ const m=p.match(/(\d+)-D(\d+)/),m2=p.match(/D(\d+)/); if(m)return sum+parseInt(m[1])*({10:71.3,13:126.7}[parseInt(m[2])]||71.3); if(m2)return sum+2*({10:71.3,13:126.7}[parseInt(m2[1])]||71.3); return sum+142.6; }, 0);
  return { Lo,B,sigma,w_load:w,M_mid:Mmid,M_end:Mend,Q_L:Q,at_top:at_t,at_bot:at_b,b_width:bw,d_depth:d,j,ft,Ma_top:mt,Ma_bot:mb,Qa:(bw*j*fs*1e-3)+(aw*fw*j/s*1e-3) };
};
window.drawBeamStressCanvas = (cid,res) => {
  const cv=typeof cid==='string'?document.getElementById(cid):cid; if(!cv)return;
  const ctx=cv.getContext('2d'),w=cv.width,h=cv.height; ctx.clearRect(0,0,w,h);
  ctx.strokeStyle='#555'; ctx.beginPath(); ctx.moveTo(30,h/2); ctx.lineTo(w-30,h/2); ctx.stroke();
  if(res.M_mid>0||res.M_end>0){
    ctx.beginPath(); ctx.strokeStyle='#3498db'; ctx.lineWidth=2; const sm=(h/2-20)/Math.max(res.M_mid*2,res.M_end*1.5,1);
    ctx.moveTo(30,h/2-res.M_end*sm); ctx.quadraticCurveTo(w/2,h/2+res.M_mid*sm*2,w-30,h/2-res.M_end*sm); ctx.stroke();
    ctx.fillStyle='#fff'; ctx.font='10px monospace'; ctx.fillText('端M='+res.M_end.toFixed(1),30,h/2-res.M_end*sm-5); ctx.fillText('中M='+res.M_mid.toFixed(1),w/2-25,h/2+res.M_mid*sm+15);
  }
};
window.updateGlobalDesignSettings = function() {
  const fcSelect = document.getElementById('globalFc');
  const sdSelect = document.getElementById('globalSD');
  if (!fcSelect || !sdSelect) return;

  const fcVal = parseInt(fcSelect.value) || 21;
  const sdVal = parseInt(sdSelect.value) || 295;
  
  const fd = floorData['1'];
  if (!fd) return;
  
  fd.globalFc = fcVal;
  fd.globalSD = sdVal;

  // Fc に応じた許容応力度 (長期)
  const fc_long = fcVal / 3.0;
  const fs_long = fcVal / 30.0;
  
  // SD に応じた許容応力度
  const ft_long = sdVal === 345 ? 215 : 195;
  const ft_short = sdVal === 345 ? 345 : 295;

  const updateBeam = (b) => {
    b.ft = ft_long;
    b.fts = ft_short;
    b.fc = fc_long;
    b.fs = fs_long;
    // 短期は長期の1.5倍
    b.fcs = fc_long * 1.5;
    b.fss = fs_long * 1.5;
  };

  if (fd.beams) fd.beams.forEach(updateBeam);
  if (fd.perimeterBeams) fd.perimeterBeams.forEach(updateBeam);

  console.log(`[Global Settings] Updated: Fc=${fcVal}, SD=${sdVal} -> ft=${ft_long}, fs=${fs_long}`);
  
  // 再計算のトリガー
  if (window.syncSlabDataToBeams) {
    window.syncSlabDataToBeams(); 
  } else if (window.updateAllBeamsShortTermStress) {
    window.updateAllBeamsShortTermStress(fd);
  }
  
  if (typeof window.callRender === 'function') window.callRender();
  if (typeof window.updatePropertyPanel === 'function') window.updatePropertyPanel();
  if (typeof window.updateDataList === 'function') window.updateDataList();
};
